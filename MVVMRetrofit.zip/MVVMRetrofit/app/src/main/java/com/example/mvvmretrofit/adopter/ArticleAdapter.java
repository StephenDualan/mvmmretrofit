package com.example.mvvmretrofit.adopter;

public class ArticleAdapter {
}
