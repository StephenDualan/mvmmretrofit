package com.example.mvvmretrofit.retrofit;

import static com.example.mvvmretrofit.constant.AppConstant.Api_KEY;
import com.example.mvvmretrofit.response.ArticleResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiRequest {

    @GET("top-headlines?sources=techcrunch&apiKey="+Api_KEY)
    Call<ArticleResponse> getTopHeadLines();
}
