package com.example.mvvmretrofit.view_model;

public class ArticleViewModel {
}
